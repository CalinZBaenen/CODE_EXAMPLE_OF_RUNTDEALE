package RuntDeale.code;

import java.io.File;
import java.net.URL;



/**
* The {@code Backpack} is meant to be a tool for accessing resources in the {@code .jar}
* file itself.
*/
public final class Backpack {

	private Backpack() {}



	/**
	* Get a file from the currently executing {@code .jar}.
	* @param url The url to get the file from/
	*/
	public static File getResource(String url) {
		try {
			return new File(Main.class.getResource(url).toURI());
		} catch(Exception exc) {}
		return null;
	}

}