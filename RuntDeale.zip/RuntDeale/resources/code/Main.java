package RuntDeale.code;

import javax.imageio.ImageIO;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.lang.String;
import java.awt.Color;



/**
* The game's main class.
*/
final class Main {

	private static final Dimension APP_MINSIZE = new Dimension(500, 400);
	private static final String APP_NAME = "RuntDeale";
	private static final float APP_VER = 0.01f;

	private final Entity player = new Entity();
	private final JFrame window;
	private final JPanel ctx;



	private Main() {
		window = new JFrame(APP_NAME);
		window.setResizable(true);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.getContentPane().setBackground(Color.BLACK);
		window.setMinimumSize(APP_MINSIZE);
		window.setLayout(null);

		window.setVisible(true);


		ctx = new JPanel();
	}



	public static void main(String[] args) {
		Main program = new Main();
		try {
			program.run();
		} catch(Exception exc) {
			program.setTitle("Exception: "+exc.getLocalizedMessage());
		}
	}



	/**
	* Run the current program instance.
	*/
	protected void run() {
		Graphics g = ctx.getGraphics();
		while(true) {
			try {
				g.drawImage(ImageIO.read(Backpack.getResource(
					"resources/textures/characters/Chloe/front/walk_0.png"
				)), (int) player.getX(), (int) player.getY(), null);
			} catch(Exception exc) {}
			window.repaint();
		}
	}



	/**
	* Set the title of program's window.
	*/
	protected void setTitle(String s) {
		window.setTitle(s);
	}

}