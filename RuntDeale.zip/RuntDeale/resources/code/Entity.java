package RuntDeale.code;

import java.util.HashMap;
import java.util.Random;
import java.awt.Image;
import java.lang.Long;
import java.lang.Math;



/**
* An {@code Entity} is an advanced object that has senses that {@code Tile}s don't.
*/
public final class Entity extends PhysicalObject {

	public static final float DEFAULT_SPEED = 1f;
	public static final int NORTH = 0;
	public static final int EAST = 1;
	public static final int SOUTH = 2;
	public static final int WEST = 3;

	private static final HashMap<Long, Entity> idpool = new HashMap<>();

	private int facing = 2;
	private float speed = DEFAULT_SPEED;
	private String name = null;
	private final Long id;



	/**
	* Create an entity facing a specified direction, with a given speed, name, and ID.
	* @param facing The direction to face.
	* @param speed The speed for the entity to move (in pixels).
	* @param name The name of the entity (one of two identifiers).
	* @param id A {@code long} associated wth this entity, and this entity only.
	*/
	private Entity(int facing, float speed, String name, long id) {
		super(0f, false, (Image) null);
		this.facing = facing;
		this.speed = speed;
		this.name = name;
		if(id != 0l) this.id = id;
		else this.id = produceID(this);
	}
	/**
	* Create an entity with a direction to face, a speed, and a name.
	* @param facing The direction to face.
	* @param speed The speed to move (in pixels).
	* @param name The "name" of the entity.
	*/
	public Entity(int facing, float speed, String name) {
		this(facing, speed, name, produceID());
	}
	/**
	* Create an entity facing a specified direction, with the specified speed.
	* @param facing The direction to face.
	* @param speed The speed for the entity to move (in pixels).
	*/
	public Entity(int facing, float speed) {
		this(facing, speed, null);
	}
	/**
	* Creates an entity facing a specified direction, with a name.
	* @param facing The direction for the entity to face.
	* @param name The name of the entity.
	*/
	public Entity(int facing, String name) {
		this(facing, DEFAULT_SPEED);
	}
	/**
	* Creates an entity facing the given direction.
	* @param facing The direction to face.
	*/
	public Entity(int facing) {
		this(facing, DEFAULT_SPEED);
	}
	/**
	* Creates an entity with a given speed (in pixels).
	* @param speed The speed to move.
	*/
	public Entity(float speed) {
		this(2, speed);
	}
	/**
	* Create a blank (generic) entity.
	*/
	public Entity() {
		super(0f, false, (Image) null);
		this.id = produceID(this);
	}


	/** 
	* Interns an entity by using an ID, if there is no entity with the given ID,
	* {@code null} is returned.
	*/
	public static Entity intern(long id) {
		final Object[] IDs = idpool.keySet().toArray();
		for(final Object ID : IDs) {
			if(ID.equals(id)) return idpool.get(ID);
		}
		return null;
	}
	/**
	* Intern an entity by using basic constructor arguments. If no such entity exists
	* it will return a new entity in place of the non-existant one.
	* @param facing Direction the entity is facing.
	* @param speed The entities speed.
	* @param name The name of the entity.
	*/
	public static Entity intern(int facing, float speed, String name) {
		final Object[] IDs = idpool.keySet().toArray();
		for(final Object ID : IDs) {
			final Entity test = idpool.get(ID);
			if(
				test.facing() == facing && test.getSpeed() == speed &&
				test.getName().equals(name)
			) return test;
		}
		return new Entity(facing, speed, name);
	}



	/**
	* Make an ID for the entity (and automatically log it to the ID pool).
	*/
	private static long produceID(Entity self) {
		long ID = produceID();
		if(!idpool.containsKey(ID)) Entity.idpool.put(ID, self);
		else ID = produceID(self);
		return ID;
	}
	/**
	* Make an ID for an entity.
	*/
	private static long produceID() {
		Random r = new Random();
		Random r2 = new Random(r.nextLong());
		final long ID = (long) Math.abs(r.nextInt()+(r2.nextInt(1000)+1));
		return ID;
	}



	/**
	* Get the direction the entity is facing.
	*/
	public int facing() {
		return facing;
	}

	/**
	* Set the direction the entity is facing.
	*/
	public void setFacing(int facing) {
		this.facing = facing;
	}


	
	/**
	* Get the speed of the entity
	*/
	public float getSpeed() {
		return speed;
	}

	/**
	* Set the speed of the entity.
	*/
	public void setSpeed(float speed) {
		this.speed = speed;
	}



	/**
	* Get the name of the entity.
	*/
	public String getName() {
		return name;
	}

	/**
	* Set the name of the entity.
	*/
	public void setName(String name) {
		this.name = name;
	}



	/**
	* Get the ID of the entity.
	*/
	public long getID() {
		return id;
	}

}