package RuntDeale.code;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.lang.Exception;
import java.awt.Image;
import java.io.File;



/**
* A {@code PhysicalObject} is a generic class that represents a phyical consumption of
* space, in the form of a generic object.
*/
public abstract class PhysicalObject {

	private Image texture;
	private float height;
	private boolean solid;
	private float x = 0f;
	private float y = 0f;



	/**
	* Make a {@code PhysicalObject} with a height, a {@code solid} flag, and a texture.
	* @param height The "height" of the object.
	* @param solid Whether or not the object is solid.
	* @param texture The texture that represents this object.
	*/
	protected PhysicalObject(float height, boolean solid, Image texture) {
		this.texture = texture;
		this.height = height;
		this.solid = solid;
	}
	/**
	* Make a {@code PhysicalObject} with a height, a {@code solid} flag, and a texture.
	* @param height The "height" of the object.
	* @param solid Whether or not the object is solid.
	* @param texture A file containing the image to represent the object.
	*/
	protected PhysicalObject(float height, boolean solid, File texture) {
		try {
			this.texture = ImageIO.read(texture);
		} catch(Exception exc) {this.texture = null;}
		this.height = height;
		this.solid = solid;
	}
	/**
	* Creates an object with a specified texture to represent it.
	* @param texture The image to represent the object.
	*/
	protected PhysicalObject(Image texture) {
		this(0f, false, texture);
	}
	/**
	* Creates an object with an image from the specified file to represent it.
	* @param texture A file containing the image to represent the object.
	*/
	protected PhysicalObject(File texture) {
		this(0f, false, texture);
	}
	/**
	* Make a {@code PhysicalObject} with a set height.
	* @param height The "height" of the object.
	*/
	protected PhysicalObject(float height) {
		this(height, false, (Image) null);
	}
	/**
	* Make an object with a set {@code solid} flag.
	* @param solid Whether or not the object is solid.
	*/
	protected PhysicalObject(boolean solid) {
		this(0f, solid, (Image) null);
	}



	/** 
	* Moves the X position of the object.
	*/
	public float moveX(float x) {
		this.x += x;
		return this.x;
	}

	/**
	* Set the X position of the object.
	* @param x The new X position.
	*/
	public void setX(float x) {
		this.x = x;
	}

	/**
	* Get the X position of the object.
	*/
	public float getX() {
		return this.x;
	}


	/** 
	* Moves the Y position of the object.
	*/
	public float moveY(float y) {
		this.y += y;
		return this.y;
	}

	/**
	* Set the Y position of the object.
	* @param y The new Y position.
	*/
	public void setY(float y) {
		this.y = y;
	}

	/**
	* Get the Y position of the object.
	*/
	public float getY() {
		return this.y;
	}



	/**
	* Get the image associated with the object.
	*/
	public Image getTexture() {
		return this.texture;
	}

	/**
	* Set the image associated with the object.
	*/
	public void setTexture(Image texture) {
		this.texture = texture;
	}

}